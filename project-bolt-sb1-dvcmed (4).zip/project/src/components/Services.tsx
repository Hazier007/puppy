import { Card } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { 
  LockKeyhole, 
  ShieldCheck, 
  KeyRound, 
  Wrench, 
  Home, 
  Clock,
  Settings,
  AlertTriangle,
  DoorClosed
} from 'lucide-react';

const services = [
  {
    icon: DoorClosed,
    title: 'Noodopening',
    description: 'Snelle en professionele noodopening service voor alle situaties',
    href: '/noodopening'
  },
  {
    icon: LockKeyhole,
    title: 'Sloten',
    description: 'Specialist in alle soorten sloten en sluitsystemen',
    href: '/sloten'
  },
  {
    icon: ShieldCheck,
    title: 'Beveiliging',
    description: 'Professionele beveiligingsoplossingen voor woning en bedrijf',
    href: '/beveiliging'
  },
  {
    icon: KeyRound,
    title: 'Sleutels',
    description: 'Sleutels bijmaken en sleutelservice voor alle systemen',
    href: '/sleutels'
  },
  {
    icon: Wrench,
    title: 'Onderhoud',
    description: 'Preventief onderhoud van sloten en beveiligingssystemen',
    href: '/onderhoud'
  },
  {
    icon: AlertTriangle,
    title: 'Inbraakschade',
    description: 'Snelle reparatie en beveiliging na inbraak(poging)',
    href: '/inbraakschade'
  },
  {
    icon: Settings,
    title: 'Installatie',
    description: 'Professionele installatie van sloten en beveiliging',
    href: '/installatie'
  },
  {
    icon: Home,
    title: 'Woningbeveiliging',
    description: 'Complete beveiligingsoplossingen voor uw woning',
    href: '/woningbeveiliging'
  },
  {
    icon: ShieldCheck,
    title: 'Bedrijfsbeveiliging',
    description: 'Specialistische beveiligingsoplossingen voor bedrijven',
    href: '/bedrijfsbeveiliging'
  }
];

export function Services() {
  return (
    <section id="diensten" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-4">Onze Diensten</h2>
        <p className="text-gray-600 text-center mb-12 max-w-2xl mx-auto">
          Professionele slotenmaker en beveiligingsspecialist voor al uw sloten, beveiliging en noodopeningen
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <Link key={service.title} to={service.href}>
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer h-full">
                <service.icon className="h-12 w-12 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}