import { Header } from '@/components/Header';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ServiceArea } from '@/components/ServiceArea';
import { cities, services } from '@/lib/cities';
import { 
  DoorClosed, 
  Key, 
  Lock, 
  Home,
  Building2,
  Car,
  Vault,
  Warehouse,
  Phone,
  MapPin,
  ArrowRight,
  Shield,
  Wrench,
  Clock,
  AlertTriangle,
  Settings
} from 'lucide-react';

const icons = {
  DoorClosed,
  Key,
  Lock,
  Home,
  Building2,
  Car,
  Vault,
  Warehouse,
  Shield,
  Wrench,
  Clock,
  AlertTriangle,
  Settings
};

export function CityPage({ city = "Aalst" }) {
  const cityData = cities.find(c => c.name === city);

  if (!cityData) {
    return <div>City not found</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-blue-900 text-white pt-24">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80')] opacity-20 bg-cover bg-center" />
        <div className="relative max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Slotenmaker {cityData.name}</h1>
            <p className="text-xl mb-8">{cityData.description}</p>
            <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-black">
              <Phone className="mr-2 h-5 w-5" />
              Bel Direct: 0468 11 33 99
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Onze Diensten in {cityData.name}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <Card key={service.name} className="p-6 hover:shadow-xl transition-shadow">
                <div className="flex items-start">
                  <Wrench className="h-12 w-12 text-blue-600 mt-1" />
                  <div className="ml-4">
                    <h3 className="text-xl font-semibold mb-2">{service.name}</h3>
                    <p className="text-gray-600 mb-4">{service.description}</p>
                    <ul className="space-y-2">
                      {service.subServices.map((subService) => (
                        <li key={subService} className="flex items-center text-sm text-gray-500">
                          <ArrowRight className="h-4 w-4 text-blue-600 mr-2" />
                          {subService}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Service Area Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Werkgebied rond {cityData.name}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {cityData.subMunicipalities.map((municipality) => (
              <Card key={municipality} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 text-blue-600 mt-1 flex-shrink-0" />
                  <div className="ml-3">
                    <h3 className="font-semibold mb-2">{municipality}</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {services.map(service => (
                        <Button 
                          key={service.name}
                          variant="outline"
                          size="sm"
                          className="text-sm justify-start"
                        >
                          <Wrench className="h-4 w-4 mr-2" />
                          {service.name}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Slotenmaker nodig in {cityData.name}?</h2>
          <p className="text-xl mb-8">
            Onze professionele slotenmakers staan 24/7 voor u klaar.
            Snelle service, eerlijke prijzen.
          </p>
          <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-black">
            <Phone className="mr-2 h-5 w-5" />
            Bel Nu: 0468 11 33 99
          </Button>
        </div>
      </section>
    </div>
  );
}