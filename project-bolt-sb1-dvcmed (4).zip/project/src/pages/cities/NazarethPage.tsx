import { CityPage } from '../CityPage';

export function NazarethPage() {
  return <CityPage city="Nazareth" />;
}