import { CityPage } from '../CityPage';

export function LaarnePage() {
  return <CityPage city="Laarne" />;
}