import { CityPage } from '../CityPage';

export function ZelePage() {
  return <CityPage city="Zele" />;
}