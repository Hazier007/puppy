import { CityPage } from '../CityPage';

export function LedePage() {
  return <CityPage city="Lede" />;
}