import { CityPage } from '../CityPage';

export function ZottegemPage() {
  return <CityPage city="Zottegem" />;
}