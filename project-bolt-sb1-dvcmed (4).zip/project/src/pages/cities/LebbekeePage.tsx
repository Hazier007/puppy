import { CityPage } from '../CityPage';

export function LebbekeePage() {
  return <CityPage city="Lebbeke" />;
}