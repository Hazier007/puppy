import { CityPage } from '../CityPage';

export function BeverenPage() {
  return <CityPage city="Beveren" />;
}