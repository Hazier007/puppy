import { CityPage } from '../CityPage';

export function MerelebekePage() {
  return <CityPage city="Merelbeke" />;
}