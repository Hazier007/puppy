import { CityPage } from '../CityPage';

export function GaverePage() {
  return <CityPage city="Gavere" />;
}