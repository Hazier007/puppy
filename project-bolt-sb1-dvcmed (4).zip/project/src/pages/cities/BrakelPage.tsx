import { CityPage } from '../CityPage';

export function BrakelPage() {
  return <CityPage city="Brakel" />;
}