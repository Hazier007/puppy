import { CityPage } from '../CityPage';

export function SintGillisWaasPage() {
  return <CityPage city="Sint-Gillis-Waas" />;
}