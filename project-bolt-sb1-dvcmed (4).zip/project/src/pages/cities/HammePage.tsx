import { CityPage } from '../CityPage';

export function HammePage() {
  return <CityPage city="Hamme" />;
}