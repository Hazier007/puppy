import { CityPage } from '../CityPage';

export function AalterPage() {
  return <CityPage city="Aalter" />;
}