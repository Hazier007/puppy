import { CityPage } from '../CityPage';

export function GeraardsbergenPage() {
  return <CityPage city="Geraardsbergen" />;
}