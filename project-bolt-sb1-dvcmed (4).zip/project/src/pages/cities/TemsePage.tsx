import { CityPage } from '../CityPage';

export function TemsePage() {
  return <CityPage city="Temse" />;
}