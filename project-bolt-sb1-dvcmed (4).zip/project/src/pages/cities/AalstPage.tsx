import { CityPage } from '../CityPage';

export function AalstPage() {
  return <CityPage city="Aalst" />;
}