import { CityPage } from '../CityPage';

export function StekenePage() {
  return <CityPage city="Stekene" />;
}