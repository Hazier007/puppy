import { CityPage } from '../CityPage';

export function LievegemPage() {
  return <CityPage city="Lievegem" />;
}