import { CityPage } from '../CityPage';

export function WichelenPage() {
  return <CityPage city="Wichelen" />;
}