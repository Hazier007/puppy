import { CityPage } from '../CityPage';

export function KruibekePage() {
  return <CityPage city="Kruibeke" />;
}