import { CityPage } from '../CityPage';

export function DeinzePage() {
  return <CityPage city="Deinze" />;
}