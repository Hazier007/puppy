import { CityPage } from '../CityPage';

export function BuggenhoutPage() {
  return <CityPage city="Buggenhout" />;
}