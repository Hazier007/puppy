import { CityPage } from '../CityPage';

export function KruisemPage() {
  return <CityPage city="Kruisem" />;
}