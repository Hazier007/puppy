import { CityPage } from '../CityPage';

export function WortegePetegemPage() {
  return <CityPage city="Wortegem-Petegem" />;
}