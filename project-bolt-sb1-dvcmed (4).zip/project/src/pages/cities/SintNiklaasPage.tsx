import { CityPage } from '../CityPage';

export function SintNiklaasPage() {
  return <CityPage city="Sint-Niklaas" />;
}