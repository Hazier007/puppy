import { CityPage } from '../CityPage';

export function SintLaurensPage() {
  return <CityPage city="Sint-Laureins" />;
}