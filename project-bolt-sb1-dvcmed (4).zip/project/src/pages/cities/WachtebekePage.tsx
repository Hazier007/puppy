import { CityPage } from '../CityPage';

export function WachtebekePage() {
  return <CityPage city="Wachtebeke" />;
}