import { CityPage } from '../CityPage';

export function OudenaardePage() {
  return <CityPage city="Oudenaarde" />;
}