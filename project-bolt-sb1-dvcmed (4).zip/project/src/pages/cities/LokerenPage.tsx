import { CityPage } from '../CityPage';

export function LokerenPage() {
  return <CityPage city="Lokeren" />;
}