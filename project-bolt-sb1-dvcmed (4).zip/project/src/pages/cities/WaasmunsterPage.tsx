import { CityPage } from '../CityPage';

export function WaasmunsterPage() {
  return <CityPage city="Waasmunster" />;
}