import { CityPage } from '../CityPage';

export function KaprijkePage() {
  return <CityPage city="Kaprijke" />;
}