import { CityPage } from '../CityPage';

export function SintLievensHoutemPage() {
  return <CityPage city="Sint-Lievens-Houtem" />;
}