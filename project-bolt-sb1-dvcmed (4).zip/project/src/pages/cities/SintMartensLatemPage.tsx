import { CityPage } from '../CityPage';

export function SintMartensLatemPage() {
  return <CityPage city="Sint-Martens-Latem" />;
}