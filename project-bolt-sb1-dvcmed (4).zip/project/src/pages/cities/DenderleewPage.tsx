import { CityPage } from '../CityPage';

export function DenderleewPage() {
  return <CityPage city="Denderleeuw" />;
}