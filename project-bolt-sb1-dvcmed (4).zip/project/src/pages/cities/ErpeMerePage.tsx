import { CityPage } from '../CityPage';

export function ErpeMerePage() {
  return <CityPage city="Erpe-Mere" />;
}