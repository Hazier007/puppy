import { CityPage } from '../CityPage';

export function OosterzelePage() {
  return <CityPage city="Oosterzele" />;
}