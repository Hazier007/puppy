import { CityPage } from '../CityPage';

export function HerzeleePage() {
  return <CityPage city="Herzele" />;
}