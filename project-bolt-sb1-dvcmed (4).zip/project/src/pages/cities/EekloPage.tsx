import { CityPage } from '../CityPage';

export function EekloPage() {
  return <CityPage city="Eeklo" />;
}