import { CityPage } from '../CityPage';

export function LochristiPage() {
  return <CityPage city="Lochristi" />;
}