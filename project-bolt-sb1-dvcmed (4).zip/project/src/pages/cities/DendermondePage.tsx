import { CityPage } from '../CityPage';

export function DendermondePage() {
  return <CityPage city="Dendermonde" />;
}