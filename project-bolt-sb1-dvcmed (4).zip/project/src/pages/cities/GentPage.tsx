import { CityPage } from '../CityPage';

export function GentPage() {
  return <CityPage city="Gent" />;
}