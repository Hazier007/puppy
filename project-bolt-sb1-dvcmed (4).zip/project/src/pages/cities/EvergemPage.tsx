import { CityPage } from '../CityPage';

export function EvergemPage() {
  return <CityPage city="Evergem" />;
}