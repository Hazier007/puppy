import { CityPage } from '../CityPage';

export function MoerbekePage() {
  return <CityPage city="Moerbeke" />;
}