import { CityPage } from '../CityPage';

export function WetterenPage() {
  return <CityPage city="Wetteren" />;
}