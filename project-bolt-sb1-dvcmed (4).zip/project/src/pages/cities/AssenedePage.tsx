import { CityPage } from '../CityPage';

export function AssenedePage() {
  return <CityPage city="Assenede" />;
}