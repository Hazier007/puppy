import { CityPage } from '../CityPage';

export function NinovePage() {
  return <CityPage city="Ninove" />;
}