import { CityPage } from '../CityPage';

export function HorebekePage() {
  return <CityPage city="Horebeke" />;
}