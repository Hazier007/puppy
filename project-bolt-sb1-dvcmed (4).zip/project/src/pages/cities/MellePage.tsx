import { CityPage } from '../CityPage';

export function MellePage() {
  return <CityPage city="Melle" />;
}