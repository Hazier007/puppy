import { CityPage } from '../CityPage';

export function LierdePage() {
  return <CityPage city="Lierde" />;
}