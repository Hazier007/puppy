import { CityPage } from '../CityPage';

export function RonsePage() {
  return <CityPage city="Ronse" />;
}