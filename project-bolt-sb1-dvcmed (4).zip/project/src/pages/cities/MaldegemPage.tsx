import { CityPage } from '../CityPage';

export function MaldegemPage() {
  return <CityPage city="Maldegem" />;
}