import { CityPage } from '../CityPage';

export function ZwalmPage() {
  return <CityPage city="Zwalm" />;
}