import { CityPage } from '../CityPage';

export function KluisbergenPage() {
  return <CityPage city="Kluisbergen" />;
}