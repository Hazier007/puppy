import { CityPage } from '../CityPage';

export function MaarkedalPage() {
  return <CityPage city="Maarkedal" />;
}