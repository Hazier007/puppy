import { CityPage } from '../CityPage';

export function DestelbergenPage() {
  return <CityPage city="Destelbergen" />;
}