import { CityPage } from '../CityPage';

export function ZelzatePage() {
  return <CityPage city="Zelzate" />;
}